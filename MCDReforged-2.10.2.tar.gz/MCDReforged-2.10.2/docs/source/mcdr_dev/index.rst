
MCDReforged Development
=======================

This part of the document is for developing MCDReforged itself. See :ref:`index-plugin-dev` if you want to develop a MCDR plugin

If you are just a user of MCDR, run! Don't read!

.. toctree::
   :maxdepth: 2

   Basic<basic.rst>
   Document<document.rst>
   Publication<publication.rst>
