
.. _class-ref-utilities:

Utilities
=========

:doc:`API package </plugin_dev/api>` path: ``mcdreforged.api.utils``

.. automodule:: mcdreforged.utils.serializer
    :members:
    :special-members: __init__
